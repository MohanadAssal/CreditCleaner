# CreditCleaner
A data processing Java application that uses searching, sorting and graphing algorithms to perform data cleaning on credit card fraud data
